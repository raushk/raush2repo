insert into city(id,name,population) values(10, 'Delhi',90000000);
insert into city(id,name,population) values(11, 'Mumbai',10000000);
insert into city(id,name,population) values(12, 'Benguluru',6700000);
insert into city(id,name,population) values(13, 'Kolkata',5600000);
insert into city(id,name,population) values(14, 'Pune',4000000);