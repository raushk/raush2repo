package com.springboot.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.cdi.Eager;
import org.springframework.stereotype.Repository;

import com.springboot.demo.model.City;
@Repository
@Eager
public interface CityRepository extends JpaRepository<City, Integer>{


}
