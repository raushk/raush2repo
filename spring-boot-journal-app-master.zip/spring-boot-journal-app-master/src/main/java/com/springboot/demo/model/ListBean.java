package com.springboot.demo.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.demo.dao.CityRepository;
@Service
public class ListBean {

	@Autowired
	CityRepository cityRepository;

	public List<String> getItems() {
		List<String> list = new ArrayList<String>();
		List<City> allCities = cityRepository.findAll();
		allCities.forEach(c -> list.add(c.getName()));
		return list;
	}
}