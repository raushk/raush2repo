# spring-boot-journal-app
Simple Spring Boot CRUD Web Application with Spring MVC, Spring Data JPA and H2 Database
